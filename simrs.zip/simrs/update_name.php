<?php
require_once __DIR__ . '/config/database.php';
$pdo->prepare("UPDATE users SET full_name = 'Dokter Demo' WHERE username IN ('doctor', 'dokter')")->execute();
echo "Nama dokter berhasil diubah menjadi Dokter Demo!\n";
