<?php
require_once __DIR__ . '/config/module_helpers.php';
simrs_require_login();

// Aksi input hasil lab
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save_result') {
        $oid = (int)($_POST['order_id'] ?? 0);
        $result = trim($_POST['lab_result'] ?? '');
        if ($oid && $result !== '') {
            $pdo->prepare("UPDATE clinical_orders SET clinical_indication = CONCAT(COALESCE(clinical_indication,''), ' | Hasil Lab: ', ?), status = 'completed' WHERE id = ?")->execute([$result, $oid]);
            simrs_flash('Hasil laboratorium berhasil disimpan & diterbitkan.');
            simrs_redirect('laboratory.php');
        }
    }
}

$msg = simrs_take_flash();

// Ambil data order lab dinamis
$labOrders = $pdo->query("
    SELECT co.id, co.order_no, co.ordered_at, co.priority, co.clinical_indication, co.status,
           p.full_name, p.medical_record_no, e.encounter_no
    FROM clinical_orders co
    JOIN encounters e ON e.id = co.encounter_id
    JOIN patients p ON p.id = e.patient_id
    WHERE co.order_type IN ('lab', 'laboratory') OR co.order_no LIKE '%LAB%'
    ORDER BY co.ordered_at DESC
")->fetchAll();

simrs_layout_start('Laboratorium Klinis', 'Laboratory');
if ($msg) echo '<div class="notice">' . simrs_h($msg) . '</div>';
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:10px;">
    <div>
        <h1 style="margin:0 0 4px;">Instalasi Laboratorium Patologi Klinis</h1>
        <div class="subtitle" style="margin-bottom:0;">Order pemeriksaan spesimen darah, urinalisis, dan validasi dokter spesialis patologi.</div>
    </div>
</div>

<div class="cards">
    <div class="card">
        <div class="label">Total Order Lab Masuk</div>
        <div class="num"><?= count($labOrders) ?></div>
        <div class="hint">Database terintegrasi</div>
    </div>
    <div class="card">
        <div class="label">Order Selesai (Completed)</div>
        <div class="num" style="color:#2d6a4f;"><?= count(array_filter($labOrders, fn($o) => $o['status'] === 'completed')) ?></div>
        <div class="hint">Tervalidasi dr. Sp.PK</div>
    </div>
    <div class="card">
        <div class="label">Menunggu Pemeriksaan</div>
        <div class="num" style="color:#d9534f;"><?= count(array_filter($labOrders, fn($o) => $o['status'] !== 'completed')) ?></div>
        <div class="hint">Perlu input nilai analyzer</div>
    </div>
</div>

<div class="panel">
    <div class="panel-title" style="display:flex; justify-content:space-between; align-items:center;">
        <span>Daftar Order Pemeriksaan Laboratorium Pasien</span>
        <input type="text" id="labSearch" placeholder="Cari nama pasien, no. order..." style="padding:6px 12px; border:1px solid #ccd7dc; border-radius:6px; font-size:13px; width:240px;">
    </div>
    <div class="tablewrap">
        <table>
            <thead>
                <tr>
                    <th>No. Order</th>
                    <th>Nama Pasien</th>
                    <th>No. RM</th>
                    <th>Waktu Order</th>
                    <th>Prioritas</th>
                    <th>Pemeriksaan & Hasil</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($labOrders as $row): ?>
                <tr class="lab-row">
                    <td><strong><?= simrs_h($row['order_no']) ?></strong></td>
                    <td><strong><?= simrs_h($row['full_name']) ?></strong></td>
                    <td><code><?= simrs_h($row['medical_record_no']) ?></code></td>
                    <td><?= date('d/m/Y H:i', strtotime($row['ordered_at'])) ?></td>
                    <td><span class="badge <?= $row['priority'] === 'stat' ? 'red' : 'secondary' ?>"><?= strtoupper(simrs_h($row['priority'])) ?></span></td>
                    <td><small><?= simrs_h($row['clinical_indication'] ?: 'Darah Lengkap (CBC), Gula Darah') ?></small></td>
                    <td><span class="badge <?= $row['status'] === 'completed' ? 'green' : 'yellow' ?>"><?= strtoupper(simrs_h($row['status'])) ?></span></td>
                    <td>
                        <?php if ($row['status'] !== 'completed'): ?>
                            <button class="btn" style="padding:4px 8px; font-size:11px;" onclick="openLabInput('<?= $row['id'] ?>', '<?= simrs_h($row['full_name']) ?>')">✍️ Input Hasil</button>
                        <?php else: ?>
                            <button class="btn secondary" style="padding:4px 8px; font-size:11px;" onclick="window.print()">🖨️ Cetak</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Input Hasil Lab -->
<div id="labModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:#fff; border-radius:10px; width:440px; padding:22px; box-shadow:0 10px 25px rgba(0,0,0,0.2);">
        <h2 style="margin:0 0 10px;">Input Hasil Laboratorium</h2>
        <div id="patientLabName" style="font-weight:bold; color:#18879b; margin-bottom:12px;"></div>
        <form method="post">
            <input type="hidden" name="action" value="save_result">
            <input type="hidden" id="labOrderId" name="order_id" value="">
            <div class="formrow" style="grid-template-columns:1fr; gap:10px;">
                <div>
                    <label>Hasil Pemeriksaan Laboratorium (Nilai Parameter) *</label>
                    <textarea name="lab_result" required rows="3" placeholder="Contoh: Hb 13.4 g/dL, Leukosit 8.400/uL, GDS 115 mg/dL (Normal)"></textarea>
                </div>
            </div>
            <div class="form-actions" style="margin-top:14px;">
                <button type="submit" class="btn">Simpan & Terbitkan Hasil</button>
                <button type="button" class="btn secondary" onclick="document.getElementById('labModal').style.display='none'">Batal</button>
            </div>
        </form>
    </div>
</div>

<script>
function openLabInput(id, name) {
    document.getElementById('labOrderId').value = id;
    document.getElementById('patientLabName').textContent = 'Pasien: ' + name;
    document.getElementById('labModal').style.display = 'flex';
}
document.getElementById('labSearch')?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.lab-row').forEach(r => r.style.display = r.innerText.toLowerCase().includes(q) ? '' : 'none');
});
</script>
<?php simrs_layout_end(); ?>
