<?php
require_once __DIR__ . "/config/module_helpers.php";
simrs_require_login();

try {
    $emrList = $pdo->query("
        SELECT p.medical_record_no, p.full_name, p.birth_date, p.sex,
               e.encounter_no, e.encounter_type, e.arrival_at, e.chief_complaint, e.status as enc_status,
               cn.subjective, cn.assessment, cn.plan,
               d.diagnosis_code, d.diagnosis_name
        FROM encounters e
        JOIN patients p ON p.id = e.patient_id
        LEFT JOIN clinical_notes cn ON cn.encounter_id = e.id
        LEFT JOIN diagnoses d ON d.encounter_id = e.id
        ORDER BY e.arrival_at DESC
        LIMIT 50
    ")->fetchAll();
} catch (Throwable $e) {
    $emrList = [];
}

simrs_layout_start("Electronic Medical Record", "EMR");
?>
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px;">
    <div>
        <h1 style="margin:0 0 4px;">Electronic Medical Record (EMR) Terpadu</h1>
        <div class="subtitle" style="margin-bottom:0;">Rekam medis elektronik terintegrasi mencakup Rawat Jalan, IGD, dan Riwayat Klinis Pasien.</div>
    </div>
</div>

<div class="panel">
    <div class="panel-title" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
        <span>Daftar Rekam Medis Pasien Terintegrasi</span>
        <input type="text" id="emrSearch" placeholder="Cari nama, no. RM, atau diagnosis..." style="padding:6px 12px; border:1px solid #ccd7dc; border-radius:6px; font-size:13px; width:260px;">
    </div>
    <div class="tablewrap">
        <table>
            <thead>
                <tr>
                    <th>No. RM</th>
                    <th>Nama Pasien</th>
                    <th>JK</th>
                    <th>Kunjungan</th>
                    <th>Keluhan & Anamnesis</th>
                    <th>Diagnosis (ICD-10)</th>
                    <th>Rencana Terapi (Plan)</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($emrList as $row): ?>
                <tr class="emr-row">
                    <td><code><?= simrs_h($row["medical_record_no"]) ?></code></td>
                    <td><strong><?= simrs_h($row["full_name"]) ?></strong></td>
                    <td><?= simrs_h($row["sex"]) ?></td>
                    <td><span class="badge secondary"><?= simrs_h($row["encounter_type"]) ?></span><br><small class="muted"><?= date("d/m/Y", strtotime($row["arrival_at"])) ?></small></td>
                    <td><small><strong>Keluhan:</strong> <?= simrs_h($row["chief_complaint"] ?: "-") ?><br><?= simrs_h(substr($row["subjective"] ?? "", 0, 70)) ?>...</small></td>
                    <td>
                        <?php if ($row["diagnosis_name"]): ?>
                            <span class="badge yellow"><strong><?= simrs_h($row["diagnosis_code"] ?: "ICD") ?></strong></span><br>
                            <small><?= simrs_h($row["diagnosis_name"]) ?></small>
                        <?php else: ?>
                            <span class="muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td><small><?= simrs_h(substr($row["plan"] ?? "-", 0, 60)) ?></small></td>
                    <td><span class="badge green"><?= simrs_h($row["enc_status"]) ?></span></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$emrList): ?>
                <tr><td colspan="8" class="muted" style="text-align:center; padding:20px;">Belum ada riwayat rekam medis.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.getElementById("emrSearch")?.addEventListener("input", function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll(".emr-row").forEach(r => {
        r.style.display = r.innerText.toLowerCase().includes(q) ? "" : "none";
    });
});
</script>
<?php simrs_layout_end(); ?>
