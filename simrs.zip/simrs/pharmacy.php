<?php
require_once __DIR__ . '/config/module_helpers.php';
simrs_require_login();

// Aksi telaah resep & penyerahan obat
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'dispense') {
        simrs_flash('Resep telah diverifikasi apoteker dan selesai disiapkan.');
        simrs_redirect('pharmacy.php');
    }
}

$msg = simrs_take_flash();

// Ambil e-resep yang ditulis dokter secara dinamis dari catatan SOAP
$rxList = $pdo->query("
    SELECT e.id as encounter_id, e.encounter_no, e.arrival_at,
           p.medical_record_no, p.full_name, p.sex,
           cn.plan as prescription_text, cn.created_at,
           u.full_name as doctor_name
    FROM encounters e
    JOIN patients p ON p.id = e.patient_id
    JOIN clinical_notes cn ON cn.encounter_id = e.id
    LEFT JOIN users u ON u.id = cn.author_id
    WHERE cn.plan IS NOT NULL AND cn.plan <> ''
    ORDER BY cn.created_at DESC
")->fetchAll();

simrs_layout_start('Farmasi & Apotek', 'Pharmacy');
if ($msg) echo '<div class="notice">' . simrs_h($msg) . '</div>';
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:10px;">
    <div>
        <h1 style="margin:0 0 4px;">Instalasi Farmasi & Pelayanan E-Resep</h1>
        <div class="subtitle" style="margin-bottom:0;">Resep elektronik terhubung langsung dari pemeriksaan dokter IGD & Poliklinik.</div>
    </div>
</div>

<div class="cards">
    <div class="card">
        <div class="label">Total E-Resep Masuk</div>
        <div class="num"><?= count($rxList) ?></div>
        <div class="hint">Dari dokter IGD / Rawat Jalan</div>
    </div>
    <div class="card">
        <div class="label">Resep Selesai Disiapkan</div>
        <div class="num" style="color:#2d6a4f;"><?= count($rxList) ?></div>
        <div class="hint">Siap diserahkan ke pasien</div>
    </div>
</div>

<div class="panel">
    <div class="panel-title" style="display:flex; justify-content:space-between; align-items:center;">
        <span>Antrean E-Resep Pasien Masuk (Real-Time Database)</span>
        <input type="text" id="rxSearch" placeholder="Cari nama pasien, obat..." style="padding:6px 12px; border:1px solid #ccd7dc; border-radius:6px; font-size:13px; width:240px;">
    </div>
    <div class="tablewrap">
        <table>
            <thead>
                <tr>
                    <th>No. Encounter</th>
                    <th>Nama Pasien</th>
                    <th>No. RM</th>
                    <th>Dokter Peresep</th>
                    <th>Rincian Resep Obat (Plan Dokter)</th>
                    <th>Waktu Resep</th>
                    <th>Status</th>
                    <th>Aksi Farmasi</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rxList as $row): ?>
                <tr class="rx-row">
                    <td><strong><?= simrs_h($row['encounter_no']) ?></strong></td>
                    <td><strong><?= simrs_h($row['full_name']) ?></strong></td>
                    <td><code><?= simrs_h($row['medical_record_no']) ?></code></td>
                    <td><?= simrs_h($row['doctor_name'] ?: 'Dokter Demo') ?></td>
                    <td><small><strong>Terapi:</strong> <?= nl2br(simrs_h($row['prescription_text'])) ?></small></td>
                    <td><?= date('d/m/Y H:i', strtotime($row['created_at'])) ?></td>
                    <td><span class="badge green">VERIFIED</span></td>
                    <td>
                        <button class="btn secondary" style="padding:4px 8px; font-size:11px;" onclick="window.print()">🖨️ Cetak Etiket</button>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rxList): ?>
                <tr><td colspan="8" class="muted" style="text-align:center; padding:20px;">Belum ada e-resep masuk. Resep yang diisi dokter pada SOAP IGD akan otomatis muncul di sini.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.getElementById('rxSearch')?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.rx-row').forEach(r => r.style.display = r.innerText.toLowerCase().includes(q) ? '' : 'none');
});
</script>
<?php simrs_layout_end(); ?>
