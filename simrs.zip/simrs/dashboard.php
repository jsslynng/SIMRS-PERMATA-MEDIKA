<?php
require_once __DIR__ . "/config/module_helpers.php";
simrs_require_login();

$role = $_SESSION["role_code"] ?? "";
$msg = "";

try {
    $patients = (int)$pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
    $appointments = (int)$pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = CURDATE()")->fetchColumn();
    $encounters = (int)$pdo->query("SELECT COUNT(*) FROM encounters WHERE DATE(arrival_at) = CURDATE() AND encounter_type = \"ED\"")->fetchColumn();
    $radiology = (int)$pdo->query("SELECT COUNT(*) FROM radiology_orders WHERE status <> \"cancelled\"")->fetchColumn();
} catch (Throwable $e) {
    $msg = simrs_db_error($e);
    $patients = $appointments = $encounters = $radiology = 0;
}

simrs_layout_start("Beranda RS", "Dashboard");
if ($msg) echo "<div class=\"errorbox\">" . simrs_h($msg) . "</div>";
?>

<div style="margin-bottom:20px;">
    <h1 style="margin:0 0 6px;">Hospital Command Center</h1>
    <div class="subtitle" style="margin-bottom:0;">Ringkasan operasional dan integrasi seluruh modul pelayanan RS Permata Medika.</div>
</div>

<div class="cards">
    <div class="card">
        <div class="label">Total Pasien Terdaftar</div>
        <div class="num"><?= number_format($patients) ?></div>
        <div class="hint">Master rekam medis pasien</div>
    </div>
    <div class="card">
        <div class="label">Pasien IGD Hari Ini</div>
        <div class="num"><?= number_format($encounters) ?></div>
        <div class="hint">Unit Gawat Darurat (ED)</div>
    </div>
    <div class="card">
        <div class="label">Order Radiologi Aktif</div>
        <div class="num"><?= number_format($radiology) ?></div>
        <div class="hint">X-Ray, CT-Scan, USG</div>
    </div>
</div>

<div class="cards">
    <div class="card">
        <div class="label">Appointment Poliklinik Hari Ini</div>
        <div class="num"><?= number_format($appointments) ?></div>
        <div class="hint">Jadwal rawat jalan & antrean</div>
    </div>
</div>

<div class="panel">
    <div class="panel-title">Akses Cepat Seluruh Modul Terintegrasi RS Permata Medika</div>
    <div style="padding:22px; display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px;">
        
        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">📅</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Scheduling & Antrean</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Pendaftaran pasien baru, jadwal dokter, & cetak tiket antrean.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="scheduling.php?view=dashboard">Buka Modul &rarr;</a>
        </div>

        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">🚨</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Gawat Darurat (IGD)</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Triase perawat, TTV kritis, rekam medis SOAP, & ICD-10.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="ed.php?view=dashboard">Buka Modul &rarr;</a>
        </div>

        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">🩺</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Rekam Medis (EMR)</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Rekam medis elektronik terintegrasi rawat jalan & IGD.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="emr.php">Buka Modul &rarr;</a>
        </div>

        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">🛏️</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Rawat Inap (Inpatient)</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Manajemen tempat tidur (BOR), kamar, & admisi bangsal.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="inpatient.php">Buka Modul &rarr;</a>
        </div>

        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">☢️</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Radiologi Diagnostik</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Order foto X-Ray/CT, template bacaan, & cetak lembar hasil.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="radiology.php?view=dashboard">Buka Modul &rarr;</a>
        </div>

        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">🔬</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Laboratorium Klinis</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Pemeriksaan hematologi, kimia darah, urinalisis, & validasi.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="laboratory.php">Buka Modul &rarr;</a>
        </div>

        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">💊</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Farmasi & CPOE</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Penerimaan resep elektronik, telaah obat, & etiket penyerahan.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="pharmacy.php">Buka Modul &rarr;</a>
        </div>

        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">💳</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Billing & Kasir</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Pembayaran kasir, verifikasi BPJS/asuransi, & cetak kuitansi.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="billing.php">Buka Modul &rarr;</a>
        </div>

        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:16px; background:#f8fafc;">
            <div style="font-size:24px; margin-bottom:8px;">📦</div>
            <div style="font-weight:bold; font-size:15px; color:#183f52;">Gudang Logistik</div>
            <p style="font-size:12px; color:#64748b; margin:6px 0 12px;">Penerimaan barang dari supplier, stok opname obat, & mutasi.</p>
            <a class="btn" style="font-size:11px; display:inline-block;" href="warehouse.php">Buka Modul &rarr;</a>
        </div>

    </div>
</div>

<?php simrs_layout_end(); ?>
