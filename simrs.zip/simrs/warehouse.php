<?php
require_once __DIR__ . '/config/module_helpers.php';
simrs_require_login();

$msg = simrs_take_flash();

simrs_layout_start('Gudang Logistik', 'Warehouse');
if ($msg) echo '<div class="notice">' . simrs_h($msg) . '</div>';
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:10px;">
    <div>
        <h1 style="margin:0 0 4px;">Gudang Farmasi & Logistik Medis Rumah Sakit</h1>
        <div class="subtitle" style="margin-bottom:0;">Penerimaan stok dari supplier, kartu stok per depo, monitoring expired date, dan mutasi.</div>
    </div>
    <div class="form-actions" style="margin:0;">
        <button class="btn" onclick="alert('Form penerimaan barang dari PBF supplier baru dibuka.')">+ Penerimaan Barang Baru</button>
    </div>
</div>

<!-- Kartu Ringkasan Stok Gudang -->
<div class="cards">
    <div class="card">
        <div class="label">Total Item Obat / Alkes</div>
        <div class="num">428 Item</div>
        <div class="hint">Gudang Utama & Depo</div>
    </div>
    <div class="card">
        <div class="label">Stok Minimum (Perlu Re-order)</div>
        <div class="num" style="color:#d9534f;">5 Item</div>
        <div class="hint">Amoxicillin, Ceftriaxone</div>
    </div>
    <div class="card">
        <div class="label">Mendekati Expired Date</div>
        <div class="num" style="color:#f59e0b;">12 Batch</div>
        <div class="hint">Kurang dari 6 bulan</div>
    </div>
</div>

<!-- Tabel Monitoring Stok Obat Asli -->
<div class="panel">
    <div class="panel-title" style="display:flex; justify-content:space-between; align-items:center;">
        <span>Monitoring Kartu Stok Logistik Farmasi</span>
        <input type="text" id="whSearch" placeholder="Cari nama obat, batch..." style="padding:6px 12px; border:1px solid #ccd7dc; border-radius:6px; font-size:13px; width:220px;">
    </div>
    <div class="tablewrap">
        <table>
            <thead>
                <tr>
                    <th>Kode Item</th>
                    <th>Nama Obat / Alkes</th>
                    <th>Kategori & Bentuk</th>
                    <th>Lokasi Rak</th>
                    <th>Batch No</th>
                    <th>Kedaluwarsa</th>
                    <th>Sisa Stok</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr class="wh-row">
                    <td><code>MED-001</code></td>
                    <td><strong>Paracetamol 500 mg</strong></td>
                    <td>Tablet &bull; Analgetik</td>
                    <td>Rak A-01 (Utama)</td>
                    <td>PCT2608C</td>
                    <td>Agustus 2028</td>
                    <td><strong>2.500 tab</strong></td>
                    <td><span class="badge green">AMAN</span></td>
                    <td>
                        <button class="btn secondary" style="padding:4px 8px; font-size:11px;" onclick="alert('Kartu stok Paracetamol: Masuk 5000 tab, Keluar Depo Ranap 1500 tab, Keluar Depo Rajal 1000 tab. Sisa: 2500 tab.')">Kartu Stok</button>
                    </td>
                </tr>
                <tr class="wh-row">
                    <td><code>MED-002</code></td>
                    <td><strong>Ceftriaxone 1 gr Injeksi</strong></td>
                    <td>Vial &bull; Antibiotik</td>
                    <td>Rak B-04 (Suhu Sejuk)</td>
                    <td>CFX2604A</td>
                    <td>Maret 2027</td>
                    <td><strong style="color:#d9534f;">15 vial</strong></td>
                    <td><span class="badge red">LOW STOCK</span></td>
                    <td>
                        <button class="btn" style="padding:4px 8px; font-size:11px;" onclick="alert('Pengajuan Surat Pesanan (SP) ke PBF Kimia Farma untuk 200 vial Ceftriaxone dibuat!')">+ Re-order</button>
                    </td>
                </tr>
                <tr class="wh-row">
                    <td><code>MED-003</code></td>
                    <td><strong>Infus Ringer Lactate 500 ml</strong></td>
                    <td>Kolf &bull; Cairan Elektrolit</td>
                    <td>Palet C-01 (Gudang Cairan)</td>
                    <td>RL2601B</td>
                    <td>Januari 2028</td>
                    <td><strong>480 kolf</strong></td>
                    <td><span class="badge green">AMAN</span></td>
                    <td>
                        <button class="btn secondary" style="padding:4px 8px; font-size:11px;" onclick="alert('Kartu stok Ringer Lactate dibuka.')">Kartu Stok</button>
                    </td>
                </tr>
                <tr class="wh-row">
                    <td><code>MED-004</code></td>
                    <td><strong>Omeprazole 20 mg Kapsul</strong></td>
                    <td>Kapsul &bull; Antasida/PPI</td>
                    <td>Rak A-05 (Utama)</td>
                    <td>OMP2602A</td>
                    <td>Februari 2027</td>
                    <td><strong>850 kap</strong></td>
                    <td><span class="badge green">AMAN</span></td>
                    <td>
                        <button class="btn secondary" style="padding:4px 8px; font-size:11px;" onclick="alert('Kartu stok Omeprazole dibuka.')">Kartu Stok</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
document.getElementById('whSearch')?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.wh-row').forEach(r => r.style.display = r.innerText.toLowerCase().includes(q) ? '' : 'none');
});
</script>
<?php simrs_layout_end(); ?>
