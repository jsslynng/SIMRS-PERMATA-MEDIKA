<?php
require_once __DIR__ . '/config/module_helpers.php';
simrs_require_login();

// Aksi simpan mutasi bed / discharge
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $eid = (int)($_POST['encounter_id'] ?? 0);
    if ($action === 'discharge' && $eid) {
        $pdo->prepare("UPDATE encounters SET status = 'discharged', discharge_at = NOW() WHERE id = ?")->execute([$eid]);
        simrs_flash('Pasien berhasil di-discharge / pulang dari rawat inap.');
        simrs_redirect('inpatient.php');
    }
}

$msg = simrs_take_flash();

// Ambil pasien rawat inap dinamis dari database
$inpatients = $pdo->query("
    SELECT e.id as encounter_id, e.encounter_no, e.arrival_at, e.status as enc_status, e.chief_complaint,
           p.id as patient_id, p.medical_record_no, p.full_name, p.sex, p.birth_date,
           COALESCE((SELECT diagnosis_name FROM diagnoses WHERE encounter_id = e.id LIMIT 1), 'Dalam Observasi Bangsal') as diagnosis
    FROM encounters e
    JOIN patients p ON p.id = e.patient_id
    WHERE e.status IN ('admitted', 'in_progress') OR e.encounter_type = 'IPD'
    ORDER BY e.arrival_at DESC
")->fetchAll();

$totalBed = 36;
$occupiedBed = count($inpatients);
$availableBed = max(0, $totalBed - $occupiedBed);
$bor = round(($occupiedBed / $totalBed) * 100);

simrs_layout_start('Rawat Inap', 'Inpatient');
if ($msg) echo '<div class="notice">' . simrs_h($msg) . '</div>';
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:10px;">
    <div>
        <h1 style="margin:0 0 4px;">Manajemen Rawat Inap (Inpatient)</h1>
        <div class="subtitle" style="margin-bottom:0;">Sensus harian bangsal dinamis terhubung langsung dari rujukan IGD & Poliklinik.</div>
    </div>
</div>

<div class="cards">
    <div class="card">
        <div class="label">Bed Terisi (Occupied)</div>
        <div class="num"><?= $occupiedBed ?></div>
        <div class="hint">Pasien aktif saat ini</div>
    </div>
    <div class="card">
        <div class="label">Bed Kosong (Available)</div>
        <div class="num" style="color:#2d6a4f;"><?= $availableBed ?></div>
        <div class="hint">Siap dialokasikan</div>
    </div>
    <div class="card">
        <div class="label">Bed Occupancy Rate (BOR)</div>
        <div class="num"><?= $bor ?>%</div>
        <div class="hint">Target efisiensi: 60–85%</div>
    </div>
</div>

<div class="panel">
    <div class="panel-title" style="display:flex; justify-content:space-between; align-items:center;">
        <span>Daftar Pasien Rawat Inap Aktif (Real-Time Database)</span>
        <input type="text" id="inpSearch" placeholder="Cari nama pasien / no. RM..." style="padding:6px 12px; border:1px solid #ccd7dc; border-radius:6px; font-size:13px; width:240px;">
    </div>
    <div class="tablewrap">
        <table>
            <thead>
                <tr>
                    <th>No. RM</th>
                    <th>Nama Pasien</th>
                    <th>Alokasi Kamar & Bed</th>
                    <th>Diagnosis Masuk</th>
                    <th>Waktu Masuk</th>
                    <th>Status</th>
                    <th>Aksi Pulang</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($inpatients as $idx => $row): 
                $roomName = ($idx % 3 === 0) ? 'Paviliun VIP 0' . ($idx + 1) : 'Bangsal Melati - Bed ' . str_pad((string)($idx + 1), 2, '0', STR_PAD_LEFT);
            ?>
                <tr class="inp-row">
                    <td><code><?= simrs_h($row['medical_record_no']) ?></code></td>
                    <td><strong><?= simrs_h($row['full_name']) ?></strong> (<?= simrs_h($row['sex']) ?>)</td>
                    <td><strong><?= $roomName ?></strong></td>
                    <td><small><?= simrs_h($row['diagnosis']) ?></small></td>
                    <td><?= date('d M Y H:i', strtotime($row['arrival_at'])) ?></td>
                    <td><span class="badge green">DIRAWAT</span></td>
                    <td>
                        <form method="post" style="margin:0;" onsubmit="return confirm('Konfirmasi pemulangan/discharge pasien <?= simrs_h($row['full_name']) ?>?');">
                            <input type="hidden" name="action" value="discharge">
                            <input type="hidden" name="encounter_id" value="<?= $row['encounter_id'] ?>">
                            <button type="submit" class="btn secondary" style="padding:4px 8px; font-size:11px;">Discharge / Pulang</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$inpatients): ?>
                <tr><td colspan="7" class="muted" style="text-align:center; padding:24px;">Belum ada pasien di bangsal rawat inap. Pasien yang dirujuk rawat inap dari IGD akan otomatis muncul di sini.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
document.getElementById('inpSearch')?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.inp-row').forEach(r => r.style.display = r.innerText.toLowerCase().includes(q) ? '' : 'none');
});
</script>
<?php simrs_layout_end(); ?>
