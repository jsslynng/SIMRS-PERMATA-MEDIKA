<?php $role = current_role(); $active = basename($_SERVER['PHP_SELF']); ?>
<aside class="sidebar">
  <div class="brand">
    <div class="brand-mark">+</div>
    <div><strong>RS PERMATA MEDIKA</strong><small>Melayani dengan hati, sehat bersama kami</small></div>
  </div>

  <?php if ($role === 'management'): ?>
    <div class="module-title">▥ &nbsp; REPORTING & DASHBOARD</div>
    <nav>
      <a class="<?= $active==='reporting.php'?'active':'' ?>" href="reporting.php">● &nbsp; Layanan</a>
      <a class="<?= $active==='finance.php'?'active':'' ?>" href="finance.php">● &nbsp; Finance</a>
    </nav>
  <?php elseif ($role === 'outpatient'): ?>
    <div class="module-title">▥ &nbsp; OUTPATIENT</div>
    <nav>
      <a class="<?= $active==='outpatient_queue.php'?'active':'' ?>" href="outpatient_queue.php">● &nbsp; Queue & Data</a>
      <a class="<?= $active==='outpatient_entry.php'?'active':'' ?>" href="outpatient_entry.php">● &nbsp; Data Entry</a>
    </nav>
  <?php elseif ($role === 'nurse'): ?>
    <div class="module-title">▥ &nbsp; NURSING</div>
    <nav>
      <a class="<?= $active==='nursing_overview.php'?'active':'' ?>" href="nursing_overview.php">● &nbsp; Patient & Care</a>
      <a class="<?= $active==='nursing_assessment.php'?'active':'' ?>" href="nursing_assessment.php">● &nbsp; Assessment</a>
    </nav>
  <?php endif; ?>

  <div class="user-box">
    <div class="avatar">👤</div>
    <div class="user-meta">
      <strong><?= htmlspecialchars(current_user()['full_name'] ?? '') ?></strong>
      <small><?= htmlspecialchars(current_user()['role_name'] ?? '') ?></small>
      <a href="logout.php">↪ Logout System</a>
    </div>
  </div>
</aside>
