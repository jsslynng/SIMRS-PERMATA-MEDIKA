<?php
require_once __DIR__.'/auth.php';
require_login();
$pageTitle = $pageTitle ?? 'Dashboard';
$pageSubtitle = $pageSubtitle ?? 'Integrated management insights across hospital units';
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= htmlspecialchars($pageTitle) ?> - RS Permata Medika</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="app-shell">
<?php include __DIR__.'/sidebar.php'; ?>
<main class="main">
  <header class="topbar">
    <div><h1><?= htmlspecialchars($pageTitle) ?> <span class="info">ⓘ</span></h1><p><?= htmlspecialchars($pageSubtitle) ?></p></div>
    <div class="top-actions"><small>Last updated: 08 Sep 2026, 17:45 WIB</small><span class="status-pill">● Data up to date</span><span class="bell">🔔</span></div>
  </header>
