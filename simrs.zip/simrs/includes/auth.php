<?php
if (session_status() === PHP_SESSION_NONE) session_start();

function is_logged_in(): bool {
    return !empty($_SESSION['user']);
}
function require_login(): void {
    if (!is_logged_in()) {
        header('Location: index.php');
        exit;
    }
}
function current_user(): array {
    return $_SESSION['user'] ?? [];
}
function current_role(): string {
    return $_SESSION['user']['role_slug'] ?? '';
}
function require_role(array $roles): void {
    require_login();
    if (!in_array(current_role(), $roles, true)) {
        http_response_code(403);
        include __DIR__ . '/forbidden.php';
        exit;
    }
}
function role_home(string $role): string {
    return match ($role) {
        'management' => 'reporting.php',
        'outpatient' => 'outpatient_queue.php',
        'nurse' => 'nursing_overview.php',
        default => 'dashboard.php',
    };
}
