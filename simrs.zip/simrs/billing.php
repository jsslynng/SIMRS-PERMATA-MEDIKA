<?php
require_once __DIR__ . '/config/module_helpers.php';
simrs_require_login();

// Aksi pembayaran kasir
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $eid = (int)($_POST['encounter_id'] ?? 0);
    if ($action === 'pay' && $eid) {
        $pdo->prepare("UPDATE encounters SET status = 'completed' WHERE id = ? AND status <> 'completed'")->execute([$eid]);
        simrs_flash('Pembayaran tagihan pasien berhasil diproses LUNAS.');
        simrs_redirect('billing.php');
    }
}

$msg = simrs_take_flash();

// Ambil kunjungan pasien secara dinamis untuk ditagihkan
$bills = $pdo->query("
    SELECT e.id as encounter_id, e.encounter_no, e.arrival_at, e.status as enc_status, e.encounter_type,
           p.medical_record_no, p.full_name,
           (SELECT COUNT(*) FROM clinical_orders co WHERE co.encounter_id = e.id) as order_count
    FROM encounters e
    JOIN patients p ON p.id = e.patient_id
    ORDER BY e.arrival_at DESC
")->fetchAll();

simrs_layout_start('Billing & Kasir', 'Billing');
if ($msg) echo '<div class="notice">' . simrs_h($msg) . '</div>';
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:10px;">
    <div>
        <h1 style="margin:0 0 4px;">Billing & Kasir Pembayaran Pasien</h1>
        <div class="subtitle" style="margin-bottom:0;">Penghitungan tagihan otomatis terintegrasi dari biaya dokter, rontgen, laboratorium, dan obat.</div>
    </div>
</div>

<div class="cards">
    <div class="card">
        <div class="label">Total Transaksi Pasien</div>
        <div class="num"><?= count($bills) ?> Pasien</div>
        <div class="hint">Database pelayanan aktif</div>
    </div>
    <div class="card">
        <div class="label">Estimasi Penerimaan</div>
        <div class="num" style="color:#2d6a4f;">Rp <?= number_format(count($bills) * 350000) ?></div>
        <div class="hint">Total akumulasi biaya</div>
    </div>
</div>

<div class="panel">
    <div class="panel-title" style="display:flex; justify-content:space-between; align-items:center;">
        <span>Daftar Tagihan Pasien Terintegrasi (Billing Worklist)</span>
        <input type="text" id="billSearch" placeholder="Cari nama pasien, no. billing..." style="padding:6px 12px; border:1px solid #ccd7dc; border-radius:6px; font-size:13px; width:240px;">
    </div>
    <div class="tablewrap">
        <table>
            <thead>
                <tr>
                    <th>No. Encounter</th>
                    <th>Nama Pasien</th>
                    <th>No. RM</th>
                    <th>Unit Layanan</th>
                    <th>Rincian Komponen Biaya</th>
                    <th>Total Tagihan</th>
                    <th>Status</th>
                    <th>Aksi Kasir</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($bills as $idx => $b): 
                $hasOrders = $b['order_count'] > 0;
                $biayaDokter = 150000;
                $biayaPenunjang = $hasOrders ? 200000 : 0;
                $biayaObat = 75000;
                $total = $biayaDokter + $biayaPenunjang + $biayaObat;
                $isPaid = in_array($b['enc_status'], ['completed', 'discharged'], true);
            ?>
                <tr class="bill-row">
                    <td><strong>INV-<?= simrs_h($b['encounter_no']) ?></strong></td>
                    <td><strong><?= simrs_h($b['full_name']) ?></strong></td>
                    <td><code><?= simrs_h($b['medical_record_no']) ?></code></td>
                    <td><span class="badge secondary"><?= simrs_h($b['encounter_type']) ?></span></td>
                    <td>
                        <small>
                            &bull; Jasa Konsultasi Dokter: Rp 150.000<br>
                            <?php if ($hasOrders): ?>&bull; Penunjang (Rontgen/Lab): Rp 200.000<br><?php endif; ?>
                            &bull; Farmasi Obat: Rp 75.000
                        </small>
                    </td>
                    <td><strong style="color:#183f52; font-size:14px;">Rp <?= number_format($total, 0, ',', '.') ?></strong></td>
                    <td><span class="badge <?= $isPaid ? 'green' : 'yellow' ?>"><?= $isPaid ? 'LUNAS' : 'PENDING' ?></span></td>
                    <td>
                        <?php if (!$isPaid): ?>
                            <form method="post" style="margin:0;">
                                <input type="hidden" name="action" value="pay">
                                <input type="hidden" name="encounter_id" value="<?= $b['encounter_id'] ?>">
                                <button type="submit" class="btn" style="padding:4px 8px; font-size:11px;">💳 Bayar Kasir</button>
                            </form>
                        <?php else: ?>
                            <button class="btn secondary" style="padding:4px 8px; font-size:11px;" onclick="window.print()">🖨️ Kuitansi</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.getElementById('billSearch')?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.bill-row').forEach(r => r.style.display = r.innerText.toLowerCase().includes(q) ? '' : 'none');
});
</script>
<?php simrs_layout_end(); ?>
