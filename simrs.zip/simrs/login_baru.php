<?php
session_start();
require_once __DIR__ . "/config/database.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $inputUser = strtolower(trim($_POST["username"] ?? ""));
    $password = $_POST["password"] ?? "";

    // Pemetaan alias otomatis agar aman jika login pakai istilah dokter/perawat/admisi
    $aliasMap = [
        "dokter" => "doctor",
        "service_doctor" => "doctor",
        "radiology_ordering" => "doctor",
        "perawat" => "triage_nurse",
        "nurse" => "triage_nurse",
        "admisi" => "registration",
        "appointment" => "registration",
        "billing" => "kasir",
        "warehouse" => "gudang"
    ];
    $username = $aliasMap[$inputUser] ?? $inputUser;

    if ($username !== "" && $password !== "") {
        try {
            $stmt = $pdo->prepare(
                "SELECT u.id, u.username, u.full_name, u.password_hash, u.status,
                        r.role_code, r.role_name
                 FROM users u
                 LEFT JOIN user_roles ur ON ur.user_id = u.id
                 LEFT JOIN roles r ON r.id = ur.role_id
                 WHERE u.username = :username
                 LIMIT 1"
            );
            $stmt->execute(["username" => $username]);
            $user = $stmt->fetch();

            if (
                $user &&
                $user["status"] === "active" &&
                password_verify($password, $user["password_hash"])
            ) {
                session_regenerate_id(true);

                $_SESSION["user_id"] = (int) $user["id"];
                $_SESSION["username"] = $user["username"];
                $_SESSION["name"] = $user["full_name"];
                $_SESSION["role_code"] = $user["role_code"] ?? "";
                $_SESSION["role"] = $user["role_name"] ?? "";
                $_SESSION["user"] = [
                    "id" => (int)$user["id"],
                    "username" => $user["username"],
                    "full_name" => $user["full_name"],
                    "role_slug" => $user["role_code"] ?? "",
                    "role_name" => $user["role_name"] ?? ""
                ];

                $roleCode = $_SESSION["role_code"];

                if (in_array($roleCode, ["registration_staff", "admisi"], true)) {
                    header("Location: scheduling.php?view=dashboard");
                } elseif (in_array($roleCode, ["radiographer", "radiologist"], true)) {
                    header("Location: radiology.php?view=dashboard");
                } elseif (in_array($roleCode, ["triage_nurse", "nurse", "ed_staff", "doctor"], true)) {
                    header("Location: ed.php");
                } else {
                    header("Location: dashboard.php");
                }
                exit;
            }

            $error = "Username atau password salah, atau akun Anda belum aktif.";
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $error = "Koneksi database gagal. Periksa apakah MySQL XAMPP sudah menyala.";
        }
    } else {
        $error = "Masukkan username dan password Anda.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — SIMRS RS Permata Medika</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; }
        body { background: linear-gradient(135deg, #0f2b38 0%, #184b61 50%, #1e6985 100%); min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px; }
        .login-card { width: 430px; max-width: 100%; background: #ffffff; padding: 40px 32px; border-radius: 14px; box-shadow: 0 15px 35px rgba(0,0,0,0.25); }
        .logo-box { text-align: center; margin-bottom: 24px; }
        .logo-box .icon { display: inline-flex; justify-content: center; align-items: center; width: 56px; height: 56px; background: #e8f4f5; border-radius: 50%; font-size: 26px; margin-bottom: 10px; }
        .logo-box h1 { color: #183b4e; font-size: 23px; font-weight: 800; }
        .logo-box p { color: #64748b; font-size: 13px; margin-top: 3px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; margin-bottom: 6px; color: #1e3a4b; font-weight: 600; font-size: 13px; }
        .form-group input { width: 100%; padding: 11px 13px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 14px; outline: none; transition: border-color .2s; }
        .form-group input:focus { border-color: #17818f; box-shadow: 0 0 0 3px rgba(23, 129, 143, 0.15); }
        .login-btn { width: 100%; padding: 12px; border: none; border-radius: 8px; background: #17818f; color: white; font-size: 15px; font-weight: 700; cursor: pointer; transition: background .2s; margin-top: 6px; }
        .login-btn:hover { background: #136a77; }
        .error { background: #fdecec; color: #b91c1c; padding: 10px 14px; border-radius: 8px; margin-bottom: 16px; font-size: 13px; text-align: center; border: 1px solid #fecaca; }
        .help-box { margin-top: 28px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center; }
        .help-box p { font-size: 12px; color: #64748b; line-height: 1.6; }
        .help-box a { color: #17818f; text-decoration: none; font-weight: 600; }
        .help-box a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo-box">
            <div class="icon">🏥</div>
            <h1>SIMRS</h1>
            <p>RS PERMATA MEDIKA INDONESIA</p>
        </div>

        <?php if ($error !== ""): ?>
            <div class="error"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Masukkan username Anda" autocomplete="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Masukkan password Anda" autocomplete="current-password" required>
            </div>
            
            <div style="display:flex; justify-content:space-between; align-items:center; font-size:12px; color:#64748b; margin-bottom:14px;">
                <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                    <input type="checkbox" id="remember"> Ingat saya
                </label>
                <a href="mailto:it-support@rspermatamedika.co.id?subject=Bantuan%20Login%20SIMRS" style="color:#17818f; text-decoration:none; font-weight:600;">Lupa password?</a>
            </div>

            <button type="submit" class="login-btn">Masuk ke Sistem &rarr;</button>
        </form>

        <!-- Informasi Bantuan Resmi Admin IT -->
        <div class="help-box">
            <p>
                Kendala akses akun atau lupa kata sandi?<br>
                Silakan hubungi <strong style="color:#183b4e;">Admin IT SIMRS</strong> di 
                <a href="mailto:it-support@rspermatamedika.co.id">it-support@rspermatamedika.co.id</a>
                <br><span style="font-size:11px; color:#94a3b8;">Unit SIMRS &bull; Ekstensi 104 &bull; Gedung Utama Lt. 2</span>
            </p>
        </div>
    </div>
</body>
</html>