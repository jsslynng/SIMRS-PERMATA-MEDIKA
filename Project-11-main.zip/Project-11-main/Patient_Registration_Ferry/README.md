# Patient Registration - Clean Build (MariaDB 3307)

A clean SIMRS-style Patient Registration web app for XAMPP / PHP 8+.

## Folder
Copy the contents into:
`D:\HIS\htdocs\Patient_Registration_Ferry`

The project is intentionally flat:
- `index.php`
- `config.php`
- `assets/style.css`
- `sql/schema.sql`

## Database
- Host: `127.0.0.1`
- Port: `3307`
- Database: `simrs_patient_registration_ferry`
- User: `root`
- Password: empty (default XAMPP)

The application creates the database, tables, and demo data automatically on first load.

## Login
- Email: `registration@hospital.test`
- Password: `password`

## URL
`http://localhost/Patient_Registration_Ferry/`

## Important
This is a clean build and does not depend on any earlier `config.php` or `index.php` files. Replace the entire contents of the old folder rather than mixing old and new files.
