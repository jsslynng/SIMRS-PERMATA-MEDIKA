CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  role VARCHAR(80) NOT NULL,
  unit_name VARCHAR(120) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS clinics (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  code VARCHAR(20) NOT NULL UNIQUE,
  location VARCHAR(120) DEFAULT '',
  status ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS doctors (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(140) NOT NULL,
  clinic_code VARCHAR(20) NOT NULL,
  schedule_days VARCHAR(120) DEFAULT '',
  schedule_hours VARCHAR(60) DEFAULT '',
  status ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS guarantors (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  code VARCHAR(20) NOT NULL UNIQUE,
  type VARCHAR(40) NOT NULL,
  status ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS patients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  medical_record_no VARCHAR(30) NOT NULL UNIQUE,
  national_id VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(140) NOT NULL,
  birth_date DATE NOT NULL,
  gender ENUM('L','P') NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(140) DEFAULT '',
  marital_status VARCHAR(30) DEFAULT '',
  address TEXT,
  blood_type VARCHAR(4) DEFAULT '',
  default_guarantor VARCHAR(120) DEFAULT '',
  status ENUM('Aktif','Arsip') NOT NULL DEFAULT 'Aktif',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_patient_name(full_name),
  INDEX idx_patient_phone(phone)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS registrations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  patient_id INT UNSIGNED NOT NULL,
  registration_date DATETIME NOT NULL,
  visit_type VARCHAR(40) NOT NULL,
  clinic_id INT UNSIGNED NOT NULL,
  doctor_name VARCHAR(140) NOT NULL,
  guarantor VARCHAR(120) NOT NULL,
  status ENUM('Menunggu','Dipanggil','Selesai','Batal') NOT NULL DEFAULT 'Menunggu',
  queue_no VARCHAR(20) NOT NULL,
  purpose VARCHAR(180) DEFAULT '',
  created_by VARCHAR(120) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reg_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
  CONSTRAINT fk_reg_clinic FOREIGN KEY (clinic_id) REFERENCES clinics(id),
  INDEX idx_reg_date(registration_date),
  INDEX idx_reg_status(status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS appointments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  patient_id INT UNSIGNED NOT NULL,
  appointment_no VARCHAR(40) NOT NULL UNIQUE,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  clinic_id INT UNSIGNED NOT NULL,
  doctor_name VARCHAR(140) NOT NULL,
  guarantor VARCHAR(120) NOT NULL,
  status ENUM('Terjadwal','Terkonfirmasi','Hadir','Batal') NOT NULL DEFAULT 'Terjadwal',
  notes VARCHAR(255) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_appt_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
  CONSTRAINT fk_appt_clinic FOREIGN KEY (clinic_id) REFERENCES clinics(id),
  INDEX idx_appt_date(appointment_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS insurance_verifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  patient_id INT UNSIGNED NOT NULL,
  guarantor VARCHAR(120) NOT NULL,
  member_no VARCHAR(60) NOT NULL,
  verification_status ENUM('Menunggu Verifikasi','Valid','Tidak Valid') NOT NULL DEFAULT 'Menunggu Verifikasi',
  verified_at DATETIME NULL,
  notes VARCHAR(255) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ins_patient FOREIGN KEY (patient_id) REFERENCES patients(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS correction_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  patient_id INT UNSIGNED NOT NULL,
  field_name VARCHAR(80) NOT NULL,
  old_value TEXT,
  new_value TEXT,
  status ENUM('Menunggu','Disetujui','Ditolak') NOT NULL DEFAULT 'Menunggu',
  requested_by VARCHAR(120) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_corr_patient FOREIGN KEY (patient_id) REFERENCES patients(id)
) ENGINE=InnoDB;
