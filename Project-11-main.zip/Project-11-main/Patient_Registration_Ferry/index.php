<?php
require_once __DIR__ . '/config.php';
$page = $_GET['page'] ?? 'dashboard';

if ($page === 'login') {
    if (current_user()) { header('Location: index.php'); exit; }
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? AND is_active = 1 LIMIT 1');
        $stmt->execute([$email]);
        $u = $stmt->fetch();
        if ($u && password_verify($password, $u['password_hash'])) {
            $_SESSION['user'] = ['id'=>$u['id'],'email'=>$u['email'],'full_name'=>$u['full_name'],'role'=>$u['role'],'unit_name'=>$u['unit_name']];
            header('Location: index.php'); exit;
        }
        $error = 'Email atau password tidak sesuai.';
    }
    $flash = get_flash();
    ?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SIMRS • Patient Registration</title><link rel="stylesheet" href="assets/style.css"></head><body>
    <div class="login-page"><section class="login-side"><div class="brand"><div class="brand-mark">+</div><div><div class="brand-title">Siloam Lippo Village</div><div class="brand-sub" style="color:#dcebee">Hospital Information System</div></div></div><div style="margin-top:40px"><div class="eyebrow" style="color:#9ee3ea">PATIENT REGISTRATION</div><h1>Front Office &amp;<br>Patient Access</h1><p>Kelola registrasi pasien, antrean, appointment, penjamin, dan validasi identitas dalam satu alur kerja terintegrasi.</p><div class="login-features"><div class="feature">Registrasi Baru &amp; Lama</div><div class="feature">Appointment &amp; Antrean</div><div class="feature">Verifikasi Penjamin</div><div class="feature">Validasi Data Pasien</div></div></div></section><section class="login-box"><div class="login-card"><div class="eyebrow">SIMRS</div><h2>Masuk ke sistem</h2><div class="sub">Gunakan akun petugas Patient Registration</div><?php if ($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?><?php if ($flash): ?><div class="alert success"><?=e($flash['message'])?></div><?php endif; ?><form method="post"><div class="field"><label>Email</label><input type="email" name="email" value="<?=e($_POST['email'] ?? '')?>" placeholder="registration@hospital.test" required></div><div class="field" style="margin-top:12px"><label>Password</label><input type="password" name="password" placeholder="Masukkan password" required></div><button class="btn primary" style="width:100%;margin-top:18px">Masuk</button></form><div class="help"><strong>Akun demo</strong><br>registration@hospital.test / password</div><div class="footer-note">Access point • Patient Registration • Port MariaDB 3307</div></div></section></div></body></html><?php exit; }

require_login();
$flash = get_flash();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['form_action'] ?? '';
    try {
        if ($action === 'new_patient') {
            $mrn = 'MR-' . date('Y') . '-' . str_pad((string)(((int)$pdo->query("SELECT COALESCE(MAX(id),0)+1 FROM patients")->fetchColumn())),5,'0',STR_PAD_LEFT);
            $stmt = $pdo->prepare('INSERT INTO patients (medical_record_no,national_id,full_name,birth_date,gender,phone,email,marital_status,address,blood_type,default_guarantor) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->execute([$mrn,trim($_POST['national_id']),trim($_POST['full_name']),$_POST['birth_date'],$_POST['gender'],trim($_POST['phone']),trim($_POST['email'] ?? ''),trim($_POST['marital_status'] ?? ''),trim($_POST['address'] ?? ''),trim($_POST['blood_type'] ?? ''),trim($_POST['guarantor'] ?? '')]);
            $pid = (int)$pdo->lastInsertId();
            $clinic = (int)$_POST['clinic_id'];
            $c = $pdo->prepare('SELECT name FROM clinics WHERE id=?'); $c->execute([$clinic]); $clinicName = $c->fetchColumn() ?: 'Poli Umum';
            $stmt = $pdo->prepare('INSERT INTO registrations (patient_id,registration_date,visit_type,clinic_id,doctor_name,guarantor,status,queue_no,purpose,created_by) VALUES (?,NOW(),?,?,?,?,"Menunggu",?,?,?)');
            $queue = 'A' . str_pad((string)(((int)$pdo->query("SELECT COALESCE(COUNT(*),0)+1 FROM registrations WHERE DATE(registration_date)=CURDATE()")->fetchColumn())),3,'0',STR_PAD_LEFT);
            $stmt->execute([$pid,'Rawat Jalan',$clinic,$_POST['doctor_name'],$_POST['guarantor'],$queue,'Pemeriksaan awal',current_user()['email']]);
            flash('success','Pasien berhasil didaftarkan dengan No. RM ' . $mrn . ' dan nomor antrean ' . $queue . '.');
            header('Location: index.php?page=new_patient'); exit;
        }
        if ($action === 'existing_registration') {
            $pid=(int)$_POST['patient_id']; $clinic=(int)$_POST['clinic_id'];
            $queue='A'.str_pad((string)(((int)$pdo->query("SELECT COUNT(*)+1 FROM registrations WHERE DATE(registration_date)=CURDATE()")->fetchColumn())),3,'0',STR_PAD_LEFT);
            $stmt=$pdo->prepare('INSERT INTO registrations (patient_id,registration_date,visit_type,clinic_id,doctor_name,guarantor,status,queue_no,purpose,created_by) VALUES (?,NOW(),?,?,?,?,"Menunggu",?,?,?)');
            $stmt->execute([$pid,$_POST['visit_type'],$clinic,$_POST['doctor_name'],$_POST['guarantor'],$queue,$_POST['purpose'] ?? 'Kunjungan pasien lama',current_user()['email']]);
            flash('success','Kunjungan berhasil dibuat. Nomor antrean ' . $queue . '.'); header('Location: index.php?page=existing_registration'); exit;
        }
        if ($action === 'appointment') {
            $no='APT-'.date('ymd').'-'.str_pad((string)(((int)$pdo->query("SELECT COUNT(*)+1 FROM appointments WHERE appointment_date=CURDATE()")->fetchColumn())),3,'0',STR_PAD_LEFT);
            $stmt=$pdo->prepare('INSERT INTO appointments (patient_id,appointment_no,appointment_date,appointment_time,clinic_id,doctor_name,guarantor,status,notes) VALUES (?,?,?,?,?,?,?,"Terjadwal",?)');
            $stmt->execute([(int)$_POST['patient_id'],$no,$_POST['appointment_date'],$_POST['appointment_time'].':00',(int)$_POST['clinic_id'],$_POST['doctor_name'],$_POST['guarantor'],trim($_POST['notes'] ?? '')]);
            flash('success','Appointment ' . $no . ' berhasil dijadwalkan.'); header('Location: index.php?page=appointments'); exit;
        }
        if ($action === 'insurance') {
            $stmt=$pdo->prepare('INSERT INTO insurance_verifications (patient_id,guarantor,member_no,verification_status,notes) VALUES (?,?,?,"Menunggu Verifikasi",?)');
            $stmt->execute([(int)$_POST['patient_id'],$_POST['guarantor'],trim($_POST['member_no']),trim($_POST['notes'] ?? '')]);
            flash('success','Permintaan verifikasi penjamin berhasil dicatat.'); header('Location: index.php?page=insurance'); exit;
        }
        if ($action === 'correction') {
            $stmt=$pdo->prepare('INSERT INTO correction_requests (patient_id,field_name,old_value,new_value,status,requested_by) VALUES (?,?,?,?,"Menunggu",?)');
            $stmt->execute([(int)$_POST['patient_id'],$_POST['field_name'],trim($_POST['old_value']),trim($_POST['new_value']),current_user()['email']]);
            flash('success','Permintaan koreksi identitas berhasil diajukan untuk verifikasi.'); header('Location: index.php?page=correction'); exit;
        }
    } catch (Throwable $e) {
        flash('error','Transaksi tidak dapat disimpan. Pastikan data wajib telah lengkap dan tidak duplikat.');
        header('Location: index.php?page=' . e($page)); exit;
    }
}

function active_page(string $p): string { global $page; return $page === $p ? 'active' : ''; }
$user=current_user();
$fullName=$user['full_name']; $initials=''; foreach(preg_split('/\s+/',trim($fullName)) as $n){$initials.=strtoupper(substr($n,0,1)); if(strlen($initials)>=2)break;}
$today=date('d M Y');

$dashboardCounts=[];
$dashboardCounts['patients']=(int)$pdo->query('SELECT COUNT(*) FROM patients WHERE status="Aktif"')->fetchColumn();
$dashboardCounts['registrations']=(int)$pdo->query('SELECT COUNT(*) FROM registrations WHERE DATE(registration_date)=CURDATE()')->fetchColumn();
$dashboardCounts['queue']=(int)$pdo->query('SELECT COUNT(*) FROM registrations WHERE DATE(registration_date)=CURDATE() AND status IN ("Menunggu","Dipanggil")')->fetchColumn();
$dashboardCounts['appointments']=(int)$pdo->query('SELECT COUNT(*) FROM appointments WHERE appointment_date=CURDATE()')->fetchColumn();

include __DIR__ . '/partials/layout.php';
