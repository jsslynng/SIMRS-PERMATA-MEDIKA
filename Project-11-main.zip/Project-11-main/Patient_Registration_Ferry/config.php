<?php
// SIMRS Patient Registration - clean build
// MariaDB/MySQL: 127.0.0.1:3307
session_start();

const DB_HOST = '127.0.0.1';
const DB_PORT = 3307;
const DB_NAME = 'simrs_patient_registration_ferry';
const DB_USER = 'root';
const DB_PASS = '';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function ensure_database(): void {
    try {
        $server = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $server->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo = db();
        $schema = file_get_contents(__DIR__ . '/sql/schema.sql');
        foreach (array_filter(array_map('trim', preg_split('/;\s*\n/', $schema))) as $statement) {
            if ($statement !== '') $pdo->exec($statement);
        }
        seed_database($pdo);
    } catch (Throwable $e) {
        throw new RuntimeException('Koneksi database belum siap. Pastikan MySQL/MariaDB aktif pada port 3307 dan username/password sesuai XAMPP. Detail: ' . $e->getMessage());
    }
}

function seed_database(PDO $pdo): void {
    $count = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ($count === 0) {
        $stmt = $pdo->prepare('INSERT INTO users (email, password_hash, full_name, role, unit_name, is_active) VALUES (?, ?, ?, ?, ?, 1)');
        $stmt->execute(['registration@hospital.test', password_hash('password', PASSWORD_DEFAULT), 'Ferry Pratama', 'Registration Officer', 'Patient Registration']);
        $stmt->execute(['supervisor@hospital.test', password_hash('password', PASSWORD_DEFAULT), 'Maya Lestari', 'Registration Supervisor', 'Patient Registration']);
    }

    if ((int)$pdo->query('SELECT COUNT(*) FROM clinics')->fetchColumn() === 0) {
        $rows = [
            ['Poli Penyakit Dalam','INT','Lantai 1','Aktif'],
            ['Poli Anak','PED','Lantai 1','Aktif'],
            ['Poli Bedah Umum','SUR','Lantai 2','Aktif'],
            ['Poli Saraf','NEU','Lantai 2','Aktif'],
            ['Poli Mata','OPH','Lantai 2','Aktif'],
            ['Poli Jantung','CAR','Lantai 3','Aktif'],
        ];
        $stmt = $pdo->prepare('INSERT INTO clinics (name, code, location, status) VALUES (?, ?, ?, ?)');
        foreach ($rows as $r) $stmt->execute($r);
    }
    if ((int)$pdo->query('SELECT COUNT(*) FROM doctors')->fetchColumn() === 0) {
        $rows = [
            ['dr. Aditya Mahendra, Sp.PD','INT','Senin–Jumat','08:00–15:00'],
            ['dr. Nadia Kusuma, Sp.A','PED','Senin–Sabtu','09:00–14:00'],
            ['dr. Raka Wijaya, Sp.B','SUR','Senin–Jumat','08:00–13:00'],
            ['dr. Sinta Larasati, Sp.N','NEU','Selasa–Sabtu','10:00–16:00'],
            ['dr. Kevin Hartono, Sp.JP','CAR','Senin–Kamis','09:00–14:00'],
        ];
        $stmt = $pdo->prepare('INSERT INTO doctors (name, clinic_code, schedule_days, schedule_hours, status) VALUES (?, ?, ?, ?, "Aktif")');
        foreach ($rows as $r) $stmt->execute($r);
    }
    if ((int)$pdo->query('SELECT COUNT(*) FROM guarantors')->fetchColumn() === 0) {
        $rows = [
            ['BPJS Kesehatan','JKN','Pemerintah','Aktif'],
            ['Prudential Indonesia','PRU','Asuransi','Aktif'],
            ['Mandiri Inhealth','MIH','Asuransi','Aktif'],
            ['Umum / Self Pay','UMUM','Mandiri','Aktif'],
        ];
        $stmt = $pdo->prepare('INSERT INTO guarantors (name, code, type, status) VALUES (?, ?, ?, ?)');
        foreach ($rows as $r) $stmt->execute($r);
    }
    if ((int)$pdo->query('SELECT COUNT(*) FROM patients')->fetchColumn() === 0) {
        $rows = [
            ['MR-2026-00001','3174011501940001','Andi Pratama','1985-01-15','L','081234560001','andi.pratama@example.test','Menikah','Jl. Merdeka No. 12, Tangerang','O','BPJS Kesehatan'],
            ['MR-2026-00002','3174012207900002','Budi Santoso','1990-07-22','L','081234560002','budi.santoso@example.test','Menikah','Jl. Melati No. 8, Tangerang','A','Umum / Self Pay'],
            ['MR-2026-00003','3174015305980003','Citra Lestari','1998-05-13','P','081234560003','citra.lestari@example.test','Belum Menikah','Jl. Kenanga No. 21, Tangerang','B','Prudential Indonesia'],
            ['MR-2026-00004','3174014502920004','Dewi Anggraini','1992-02-05','P','081234560004','dewi.anggraini@example.test','Menikah','Jl. Mawar Raya No. 17, Tangerang','AB','BPJS Kesehatan'],
            ['MR-2026-00005','3174011012850005','Eko Kurniawan','1985-12-10','L','081234560005','eko.kurniawan@example.test','Menikah','Jl. Diponegoro No. 31, Tangerang','O','Mandiri Inhealth'],
            ['MR-2026-00006','3174017006980006','Fani Maharani','1998-06-30','P','081234560006','fani.maharani@example.test','Belum Menikah','Jl. Sudirman No. 5, Tangerang','A','BPJS Kesehatan'],
            ['MR-2026-00007','3174012107760007','Gilang Saputra','1976-07-21','L','081234560007','gilang.saputra@example.test','Menikah','Jl. Gatot Subroto No. 44, Tangerang','B','Umum / Self Pay'],
            ['MR-2026-00008','3174014508100008','Hana Permata','2010-10-05','P','081234560008','hana.permata@example.test','Belum Menikah','Jl. Ahmad Yani No. 9, Tangerang','O','BPJS Kesehatan'],
        ];
        $stmt = $pdo->prepare('INSERT INTO patients (medical_record_no,national_id,full_name,birth_date,gender,phone,email,marital_status,address,blood_type,default_guarantor) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
        foreach ($rows as $r) $stmt->execute($r);
    }
    if ((int)$pdo->query('SELECT COUNT(*) FROM registrations')->fetchColumn() === 0) {
        $patients = $pdo->query('SELECT id, medical_record_no, full_name FROM patients ORDER BY id')->fetchAll();
        $clinics = $pdo->query('SELECT id, name, code FROM clinics ORDER BY id')->fetchAll();
        $statuses = ['Menunggu','Dipanggil','Selesai'];
        $stmt = $pdo->prepare('INSERT INTO registrations (patient_id,registration_date,visit_type,clinic_id,doctor_name,guarantor,status,queue_no,purpose,created_by) VALUES (?,?, ?,?,?,?,?,?,?,?)');
        foreach ($patients as $i => $p) {
            $c = $clinics[$i % count($clinics)];
            $date = date('Y-m-d H:i:s', strtotime('-'.($i % 5).' hours'));
            $stmt->execute([$p['id'],$date,$i%2===0?'Rawat Jalan':'Kontrol',$c['id'], ['dr. Aditya Mahendra, Sp.PD','dr. Nadia Kusuma, Sp.A','dr. Sinta Larasati, Sp.N'][$i%3], $i%3===0?'BPJS Kesehatan':($i%3===1?'Umum / Self Pay':'Prudential Indonesia'), $statuses[$i%3], 'A'.str_pad((string)($i+1),3,'0',STR_PAD_LEFT), $i%2===0?'Konsultasi Poli':'Kontrol lanjutan', 'registration@hospital.test']);
        }
    }
    if ((int)$pdo->query('SELECT COUNT(*) FROM appointments')->fetchColumn() === 0) {
        $patients = $pdo->query('SELECT id FROM patients ORDER BY id LIMIT 5')->fetchAll(PDO::FETCH_COLUMN);
        $clinics = $pdo->query('SELECT id FROM clinics ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);
        $stmt = $pdo->prepare('INSERT INTO appointments (patient_id,appointment_no,appointment_date,appointment_time,clinic_id,doctor_name,guarantor,status,notes) VALUES (?,?,?,?,?,?,?,?,?)');
        foreach ($patients as $i => $pid) {
            $d = date('Y-m-d', strtotime('+' . (($i % 4)+1) . ' day'));
            $stmt->execute([$pid,'APT-'.date('ymd').'-'.str_pad((string)($i+1),3,'0',STR_PAD_LEFT),$d,($i%4+8).':'.($i%2?'30':'00').':00',$clinics[$i%count($clinics)],'dr. '.['Aditya Mahendra, Sp.PD','Nadia Kusuma, Sp.A','Raka Wijaya, Sp.B','Sinta Larasati, Sp.N'][$i%4],$i%2?'BPJS Kesehatan':'Umum / Self Pay',$i===0?'Terjadwal':'Terkonfirmasi','Dibuat melalui loket dan kanal appointment']);
        }
    }
}

ensure_database();

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    header('Location: index.php?page=login&logged_out=1');
    exit;
}

$pdo = db();

if (!function_exists('e')) {
    function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
}

function flash(string $type, string $message): void { $_SESSION['_flash'] = ['type'=>$type,'message'=>$message]; }
function get_flash(): ?array { $f = $_SESSION['_flash'] ?? null; unset($_SESSION['_flash']); return $f; }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!current_user()) { header('Location: index.php?page=login'); exit; } }
