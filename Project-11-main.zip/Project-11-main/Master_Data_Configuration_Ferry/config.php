<?php
session_start();
const DB_HOST = '127.0.0.1';
const DB_PORT = 3307;
const DB_NAME = 'simrs_master_data';
const DB_USER = 'root';
const DB_PASS = '';

function phpq($s){return var_export($s,true);}
function db_server(){ static $pdo=null; if($pdo instanceof PDO)return $pdo; try{ $pdo=new PDO('mysql:host='.DB_HOST.';port='.DB_PORT,DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }catch(Throwable $e){ http_response_code(500); exit('Database MariaDB tidak dapat diakses. Pastikan MySQL/MariaDB berjalan pada port 3307.'); } return $pdo; }
function db(){ static $pdo=null; if($pdo instanceof PDO)return $pdo; $server=db_server(); $server->exec("CREATE DATABASE IF NOT EXISTS `".DB_NAME."` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"); $pdo=new PDO('mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME,DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); initialize_db($pdo); return $pdo; }
function initialize_db(PDO $pdo){
  $schema=__DIR__.'/database.sql';
  if(is_file($schema)){ $sql=file_get_contents($schema); $statements=preg_split('/;\s*(?:\r?\n|$)/',$sql); foreach($statements as $stmt){ $stmt=trim($stmt); if($stmt!==''){ try{$pdo->exec($stmt);}catch(Throwable $e){} } } }
  seed_user($pdo,'itadmin@hospital.test','System Administrator','Master Data Administrator');seed_user($pdo,'admin@hospital.test','Administrator SIMRS','System Administrator');
  seed_demo_data($pdo);
}

function seed_demo_data(PDO $pdo){
try{ if((int)$pdo->query('SELECT COUNT(*) FROM units')->fetchColumn()===0){
$s=$pdo->prepare('INSERT INTO units(code,name,type,location,status) VALUES(?,?,?,?,?)'); foreach([['POLI-PD','Poli Penyakit Dalam','Outpatient','Gedung A Lt. 2','Active'],['POLI-AN','Poli Anak','Outpatient','Gedung A Lt. 2','Active'],['POLI-NR','Poli Neurologi','Outpatient','Gedung A Lt. 3','Active'],['IGD','Instalasi Gawat Darurat','Emergency','Gedung Utama Lt. 1','Active'],['LAB','Laboratorium Klinik','Diagnostic','Gedung Penunjang Lt. 1','Active']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO staff(employee_no,name,profession,unit,license_no,status) VALUES(?,?,?,?,?,?)'); foreach([['EMP-0012','dr. Budi Santoso, Sp.PD','Physician','Poli Penyakit Dalam','SIP-3172/PD','Active'],['EMP-0018','dr. Clara Wijaya, Sp.A','Physician','Poli Anak','SIP-3172/AN','Active'],['EMP-0021','dr. Dimas Pratama, Sp.B','Physician','Poli Bedah','SIP-3172/BE','Active'],['EMP-0027','dr. Rania Putri, Sp.N','Physician','Poli Neurologi','SIP-3172/NE','Active'],['EMP-0042','Ns. Siti Rahma','Nurse','Rawat Jalan','STR-90123','Active'],['EMP-0051','Andri Wijaya','Registration Officer','Front Office','REG-22051','Active']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO service_catalog(code,name,category,tariff,status) VALUES(?,?,?,?,?)'); foreach([['SRV-PD01','Konsultasi Penyakit Dalam','Outpatient',185000,'Active'],['SRV-AN01','Konsultasi Anak','Outpatient',175000,'Active'],['SRV-NR01','Konsultasi Neurologi','Outpatient',225000,'Active'],['SRV-ECG','Elektrokardiografi','Diagnostic',165000,'Active'],['SRV-CBC','Hematologi Lengkap','Laboratory',110000,'Active'],['SRV-USG','Ultrasonografi Abdomen','Diagnostic',325000,'Active']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO insurance_plans(code,name,type,coverage,status) VALUES(?,?,?,?,?)'); foreach([['BPJS','BPJS Kesehatan','National Health Insurance','Rawat jalan tingkat lanjutan dan sesuai manfaat','Active'],['PRIV','Pribadi / Umum','Self Pay','Pembayaran pribadi sesuai tarif rumah sakit','Active'],['AIA','AIA Health','Private Insurance','Rawat jalan dan pemeriksaan penunjang sesuai polis','Active'],['MANU','Manulife Health','Private Insurance','Rawat jalan dan rawat inap sesuai polis','Active']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO rooms(room_no,name,unit,class_name,capacity,status) VALUES(?,?,?,?,?,?)'); foreach([['POLI-A201','Ruang Konsultasi 01','Poli Penyakit Dalam','Outpatient',1,'Available'],['POLI-A202','Ruang Konsultasi 02','Poli Anak','Outpatient',1,'Available'],['UGD-01','Bed Observasi 01','Instalasi Gawat Darurat','Emergency',1,'In Use'],['UGD-02','Bed Observasi 02','Instalasi Gawat Darurat','Emergency',1,'Available'],['LAB-01','Ruang Sampling','Laboratorium Klinik','Diagnostic',4,'Available']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO system_params(param_key,param_value,description) VALUES(?,?,?)'); foreach([['REG_QUEUE_PREFIX','A','Prefix antrean registrasi pasien baru'],['RM_PREFIX','MRN','Prefix nomor rekam medis'],['DEFAULT_APPOINTMENT_MIN','30','Durasi slot appointment standar'],['BPJS_CHECK_REQUIRED','YES','Wajib validasi penjamin BPJS sebelum registrasi'],['AUDIT_LOGGING','ENABLED','Pencatatan aktivitas pengguna sistem']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO audit_logs(user_id,action,module,reference_no) VALUES(?,?,?,?)'); foreach([['1','Master data service units reviewed','Service Units','UNIT-2026-0103'],['1','Service catalog tariff updated','Service Catalog','SRV-CBC'],['1','Insurance plan reviewed','Insurance Plans','BPJS'],['1','System parameter synchronized','Parameters','RM_PREFIX'],['1','User access reviewed','User Accounts','USR-001']] as $x)$s->execute($x);
}}
catch(Throwable $e){}
}

function seed_user(PDO $pdo,$email,$name,$role){
  $st=$pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1'); $st->execute([$email]); $u=$st->fetch();
  if($u){ $upd=$pdo->prepare("UPDATE users SET full_name=?,role=?,status='Active',password_hash=? WHERE id=?"); $upd->execute([$name,$role,password_hash('password',PASSWORD_DEFAULT),$u['id']]); }
  else{ $ins=$pdo->prepare('INSERT INTO users(full_name,email,password_hash,role,status) VALUES(?,?,?,?,?)'); $ins->execute([$name,$email,password_hash('password',PASSWORD_DEFAULT),$role,'Active']); }
}
function require_login(){ if(empty($_SESSION['user_id'])){ header('Location: login.php'); exit; } }
function current_user(){ $pdo=db(); $st=$pdo->prepare('SELECT * FROM users WHERE id=?'); $st->execute([$_SESSION['user_id']??0]); return $st->fetch() ?: ['full_name'=>'Operator','role'=>'Staff']; }
function redirect($url){ header('Location: '.$url); exit; }
?>