# SIMRS Master Data & Configuration

Folder: `master_data_configuration`

URL: `http://localhost/master_data_configuration/`
Database: `simrs_master_data` on `127.0.0.1:3307`

Demo: `itadmin@hospital.test` / `password`

Fokus modul: service units, staff & clinicians, service catalog, insurance plans, rooms/capacity, system parameters, user accounts, audit trail.
