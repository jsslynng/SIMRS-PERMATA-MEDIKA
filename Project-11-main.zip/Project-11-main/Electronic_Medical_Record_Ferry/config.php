<?php
session_start();
const DB_HOST = '127.0.0.1';
const DB_PORT = 3307;
const DB_NAME = 'simrs_emr';
const DB_USER = 'root';
const DB_PASS = '';

function phpq($s){return var_export($s,true);}
function db_server(){ static $pdo=null; if($pdo instanceof PDO)return $pdo; try{ $pdo=new PDO('mysql:host='.DB_HOST.';port='.DB_PORT,DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }catch(Throwable $e){ http_response_code(500); exit('Database MariaDB tidak dapat diakses. Pastikan MySQL/MariaDB berjalan pada port 3307.'); } return $pdo; }
function db(){ static $pdo=null; if($pdo instanceof PDO)return $pdo; $server=db_server(); $server->exec("CREATE DATABASE IF NOT EXISTS `".DB_NAME."` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"); $pdo=new PDO('mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME,DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); initialize_db($pdo); return $pdo; }
function initialize_db(PDO $pdo){
  $schema=__DIR__.'/database.sql';
  if(is_file($schema)){ $sql=file_get_contents($schema); $statements=preg_split('/;\s*(?:\r?\n|$)/',$sql); foreach($statements as $stmt){ $stmt=trim($stmt); if($stmt!==''){ try{$pdo->exec($stmt);}catch(Throwable $e){} } } }
  seed_user($pdo,'doctor@hospital.test','dr. Rania Putri, Sp.N','Physician');seed_user($pdo,'admin@hospital.test','Administrator SIMRS','System Administrator');
  seed_demo_data($pdo);
}

function seed_demo_data(PDO $pdo){
try{ if((int)$pdo->query('SELECT COUNT(*) FROM patients')->fetchColumn()===0){
$pats=[['MRN-EMR-0001','Andi Pratama','2000-04-12','Laki-laki','08123456789','Tidak ada','O'],['MRN-EMR-0002','Maya Lestari','1997-11-09','Perempuan','08129876543','Amoksisilin','A'],['MRN-EMR-0003','Bima Santoso','1988-02-23','Laki-laki','081277711122','Tidak ada','B'],['MRN-EMR-0004','Citra Wijaya','2004-08-15','Perempuan','081233344455','NSAID','AB'],['MRN-EMR-0005','Denny Kurniawan','1979-06-30','Laki-laki','081266677788','Tidak ada','O']];
$s=$pdo->prepare('INSERT INTO patients(mrn,name,birth_date,gender,phone,allergies,blood_type) VALUES(?,?,?,?,?,?,?)'); foreach($pats as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO encounters(patient_id,visit_date,clinic,doctor,status,chief_complaint) VALUES(?,?,?,?,?,?)'); $enc=[]; foreach([[1,'2026-10-03','Poli Neurologi','dr. Rania Putri, Sp.N','Open','Nyeri kepala dan sulit konsentrasi'],[2,'2026-10-03','Poli Penyakit Dalam','dr. Budi Santoso, Sp.PD','Completed','Mudah lelah sejak 2 minggu'],[3,'2026-10-02','Poli Bedah','dr. Dimas Pratama, Sp.B','Completed','Nyeri perut kanan bawah'],[4,'2026-10-02','Poli Anak','dr. Clara Wijaya, Sp.A','Open','Demam dan batuk'],[5,'2026-10-01','Poli Penyakit Dalam','dr. Budi Santoso, Sp.PD','Completed','Kontrol hipertensi']] as $x){$s->execute($x);$enc[]=$pdo->lastInsertId();}
$s=$pdo->prepare('INSERT INTO vitals(encounter_id,bp,pulse,resp,temp,spo2,weight,height) VALUES(?,?,?,?,?,?,?,?)'); foreach([[$enc[0],'128/78',78,18,36.7,98,64,170],[$enc[1],'132/82',84,19,36.8,99,58,162],[$enc[2],'140/88',92,20,37.4,97,71,173],[$enc[3],'118/72',96,22,38.1,98,49,158],[$enc[4],'136/84',80,18,36.6,99,76,175]] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO diagnoses(encounter_id,code,diagnosis,type) VALUES(?,?,?,?)'); foreach([[$enc[0],'R51','Headache','Working'],[$enc[1],'R53.1','Weakness','Primary'],[$enc[2],'R10.31','Right lower quadrant abdominal pain','Working'],[$enc[3],'J06.9','Acute upper respiratory infection','Working'],[$enc[4],'I10','Essential hypertension','Primary']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO soap_notes(encounter_id,subjective,objective,assessment,plan) VALUES(?,?,?,?,?)'); foreach([[$enc[0],'Nyeri kepala terutama sore hari setelah aktivitas dengan smartphone.','BP 128/78 mmHg, neurologis dalam batas normal.','Headache, perlu evaluasi pola pemicu.','Edukasi postur, hidrasi, sleep hygiene, follow-up.'],[$enc[1],'Keluhan lemas dan stamina menurun.','Tanda vital stabil, konjungtiva agak pucat.','Fatigue, pertimbangkan evaluasi anemia.','Laboratorium darah lengkap dan follow-up.'],[$enc[2],'Nyeri kuadran kanan bawah sejak pagi.','Nyeri tekan lokal, afebris ringan.','Abdominal pain, evaluasi bedah.','Observasi dan pemeriksaan penunjang.']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO medications(encounter_id,drug,dose,frequency,route,status) VALUES(?,?,?,?,?,?)'); foreach([[$enc[0],'Paracetamol','500 mg','3 x sehari','Oral','Active'],[$enc[1],'Ferrous sulfate','300 mg','1 x sehari','Oral','Active'],[$enc[4],'Amlodipine','5 mg','1 x sehari','Oral','Active']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO lab_results(encounter_id,test_name,result_value,unit,reference_range,status) VALUES(?,?,?,?,?,?)'); foreach([[$enc[1],'Hemoglobin','11.1','g/dL','12.0–16.0','Reported'],[$enc[1],'Leukocyte','7.8','10^3/uL','4.0–10.0','Reported'],[$enc[4],'Creatinine','0.9','mg/dL','0.6–1.2','Reported']] as $x)$s->execute($x);
$s=$pdo->prepare('INSERT INTO clinical_tasks(encounter_id,title,owner,status,due_date) VALUES(?,?,?,?,?)'); foreach([[$enc[0],'Review headache diary','dr. Rania Putri, Sp.N','Pending','2026-10-05'],[$enc[3],'Review CBC result','dr. Clara Wijaya, Sp.A','Pending','2026-10-04'],[$enc[1],'Follow-up anemia workup','dr. Budi Santoso, Sp.PD','Completed','2026-10-02'],[$enc[4],'Blood pressure log review','dr. Budi Santoso, Sp.PD','Pending','2026-10-06']] as $x)$s->execute($x);
}
}catch(Throwable $e){}
}

function seed_user(PDO $pdo,$email,$name,$role){
  $st=$pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1'); $st->execute([$email]); $u=$st->fetch();
  if($u){ $upd=$pdo->prepare("UPDATE users SET full_name=?,role=?,status='Active',password_hash=? WHERE id=?"); $upd->execute([$name,$role,password_hash('password',PASSWORD_DEFAULT),$u['id']]); }
  else{ $ins=$pdo->prepare('INSERT INTO users(full_name,email,password_hash,role,status) VALUES(?,?,?,?,?)'); $ins->execute([$name,$email,password_hash('password',PASSWORD_DEFAULT),$role,'Active']); }
}
function require_login(){ if(empty($_SESSION['user_id'])){ header('Location: login.php'); exit; } }
function current_user(){ $pdo=db(); $st=$pdo->prepare('SELECT * FROM users WHERE id=?'); $st->execute([$_SESSION['user_id']??0]); return $st->fetch() ?: ['full_name'=>'Operator','role'=>'Staff']; }
function redirect($url){ header('Location: '.$url); exit; }
?>