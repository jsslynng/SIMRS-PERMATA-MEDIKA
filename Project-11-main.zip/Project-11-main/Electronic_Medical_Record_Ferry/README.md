# SIMRS Electronic Medical Record

Folder: `electronic_medical_record`

URL: `http://localhost/electronic_medical_record/`
Database: `simrs_emr` on `127.0.0.1:3307`

Demo: `doctor@hospital.test` / `password`

Fokus modul: patient list, patient chart, encounters, SOAP, vitals, diagnoses, medication orders, laboratory, clinical tasks.
