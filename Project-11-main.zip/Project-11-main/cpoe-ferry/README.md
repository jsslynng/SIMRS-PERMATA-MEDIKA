# CPOE SIMRS - Teman Edition

Versi sederhana dan rapi untuk demo/akademik.

## Struktur
- `index.php` — login + seluruh halaman aplikasi
- `config/config.php` — koneksi database
- `assets/style.css` — desain sesuai palette yang diberikan
- `database.sql` — database + seed data

## Setup
1. Extract folder ke `D:\HIS\htdocs\cpoe-teman-teal` (atau `c:\xampp\htdocs\...`).
2. Import `database.sql` ke MariaDB/MySQL.
3. Sesuaikan `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS` di `config/config.php` bila perlu.
4. Buka `http://localhost/cpoe-teman-teal/`.

## Demo login
Password demo mengikuti username masing-masing:
- dokter123 untuk dokter
- perawat123 untuk perawat
- lab123 untuk lab
- farmasi123 untuk farmasi
- radiologi123 untuk radiologi
- gizi123 untuk gizi
- admin123 untuk admin

Username:
- dokter
- perawat
- lab
- farmasi
- radiologi
- gizi
- admin

Catatan: untuk demo lokal/akademik, bukan deployment klinis produksi.
