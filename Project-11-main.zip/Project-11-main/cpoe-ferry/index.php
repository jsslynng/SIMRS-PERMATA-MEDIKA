<?php
require __DIR__ . '/config/config.php';

$page = $_GET['page'] ?? 'dashboard';

if ($page === 'logout') {
    session_destroy();
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $page === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = db()->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user;
        db()->prepare('INSERT INTO audit_logs (user_id, action, description) VALUES (?, ?, ?)')->execute([$user['id'], 'LOGIN', 'Pengguna masuk ke CPOE']);
        redirect('dashboard');
    }
    $login_error = 'Username atau password salah.';
}

if (!current_user()) {
    $pageTitle = 'Masuk';
    ?>
    <!doctype html>
    <html lang="id">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CPOE • SIMRS</title>
      <link rel="stylesheet" href="assets/style.css">
    </head>
    <body class="login-page">
      <div class="login-card">
        <div class="login-brand"><span class="brand-mark">C</span><div><strong>CPOE</strong><small>SIMRS • Order Management</small></div></div>
        <h1>Masuk ke sistem</h1>
        <p class="muted">Gunakan akun demo untuk mencoba modul.</p>
        <?php if (!empty($login_error)): ?><div class="alert danger"><?= e($login_error) ?></div><?php endif; ?>
        <form method="post" action="index.php?page=login" class="form-stack">
          <label>Username<input type="text" name="username" required placeholder="contoh: dokter"></label>
          <label>Password<input type="password" name="password" required placeholder="Password"></label>
          <button class="btn primary" type="submit">Masuk</button>
        </form>
        <div class="demo-box"><strong>Akun demo</strong><div>dokter / dokter123</div><div>lab / lab123</div><div>farmasi / farmasi123</div></div>
      </div>
    </body>
    </html>
    <?php
    exit;
}

require_login();
$user = current_user();
$pdo = db();

if ($page === 'new_order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $patientId = (int)($_POST['patient_id'] ?? 0);
    $type = $_POST['order_type'] ?? 'Laboratorium';
    $priority = $_POST['priority'] ?? 'Rutin';
    $detail = trim($_POST['detail'] ?? '');
    $target = $_POST['target_unit'] ?? 'Laboratorium';
    $orderNo = 'ORD-' . date('YmdHis') . '-' . random_int(10,99);
    $stmt = $pdo->prepare('INSERT INTO orders (order_no, patient_id, doctor_id, order_type, priority, detail, target_unit) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$orderNo, $patientId, $user['id'], $type, $priority, $detail, $target]);
    $pdo->prepare('INSERT INTO audit_logs (user_id, action, description) VALUES (?, ?, ?)')->execute([$user['id'], 'CREATE_ORDER', 'Membuat order ' . $orderNo]);
    redirect('orders');
}

if ($page === 'update_order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? 'Diproses';
    $result = trim($_POST['result_text'] ?? '');
    $pdo->prepare('UPDATE orders SET status = ?, result_text = ? WHERE id = ?')->execute([$status, $result ?: null, $id]);
    $pdo->prepare('INSERT INTO audit_logs (user_id, action, description) VALUES (?, ?, ?)')->execute([$user['id'], 'UPDATE_ORDER', 'Memperbarui status order #' . $id . ' menjadi ' . $status]);
    redirect('workqueue');
}

function page_content(string $page, PDO $pdo, array $user): string {
    ob_start();
    if ($page === 'dashboard') {
        $counts = $pdo->query("SELECT status, COUNT(*) total FROM orders GROUP BY status")->fetchAll();
        $map = ['Menunggu Validasi'=>0,'Dikirim'=>0,'Diproses'=>0,'Selesai'=>0]; foreach ($counts as $c) { if (isset($map[$c['status']])) $map[$c['status']] = (int)$c['total']; }
        $recent = $pdo->query("SELECT o.order_no,p.full_name,o.order_type,o.priority,o.status,o.created_at FROM orders o JOIN patients p ON p.id=o.patient_id ORDER BY o.created_at DESC LIMIT 8")->fetchAll();
        ?>
        <div class="page-head"><div><span class="eyebrow">CPOE • ORDER MANAGEMENT</span><h1>Dashboard</h1><p class="muted">Ringkasan order medis untuk <?= e($user['full_name']) ?>.</p></div><a class="btn primary" href="index.php?page=new_order">+ Buat Order</a></div>
        <div class="stats-grid">
          <div class="stat"><span>Menunggu Validasi</span><strong><?= $map['Menunggu Validasi'] ?></strong><small>Perlu review</small></div>
          <div class="stat"><span>Dikirim</span><strong><?= $map['Dikirim'] ?></strong><small>Ke unit tujuan</small></div>
          <div class="stat"><span>Diproses</span><strong><?= $map['Diproses'] ?></strong><small>Sedang dikerjakan</small></div>
          <div class="stat"><span>Selesai</span><strong><?= $map['Selesai'] ?></strong><small>Sudah tervalidasi</small></div>
        </div>
        <section class="panel"><div class="panel-head"><div><h2>Order terbaru</h2><p class="muted">Aktivitas order terbaru di sistem.</p></div><a href="index.php?page=orders">Lihat semua</a></div><div class="table-wrap"><table><thead><tr><th>Order</th><th>Pasien</th><th>Jenis</th><th>Prioritas</th><th>Status</th></tr></thead><tbody><?php foreach ($recent as $r): ?><tr><td><?= e($r['order_no']) ?></td><td><?= e($r['full_name']) ?></td><td><?= e($r['order_type']) ?></td><td><?= e($r['priority']) ?></td><td><span class="badge <?= strtolower(str_replace(' ','-', $r['status'])) ?>"><?= e($r['status']) ?></span></td></tr><?php endforeach; if (!$recent): ?><tr><td colspan="5" class="empty">Belum ada order.</td></tr><?php endif; ?></tbody></table></div></section>
        <?php
    } elseif ($page === 'patients') {
        $patients = $pdo->query('SELECT * FROM patients ORDER BY full_name')->fetchAll();
        ?><div class="page-head"><div><span class="eyebrow">MASTER PASIEN</span><h1>Pasien</h1><p class="muted">Data pasien yang tersedia untuk pembuatan order.</p></div></div><section class="panel"><div class="table-wrap"><table><thead><tr><th>No. RM</th><th>Nama</th><th>JK</th><th>Ruangan</th><th>Alergi</th><th>Diagnosis</th></tr></thead><tbody><?php foreach($patients as $p): ?><tr><td><?= e($p['medical_record_no']) ?></td><td><?= e($p['full_name']) ?></td><td><?= e($p['gender']) ?></td><td><?= e($p['room']) ?></td><td><?= e($p['allergy']) ?></td><td><?= e($p['diagnosis']) ?></td></tr><?php endforeach; ?></tbody></table></div></section><?php
    } elseif ($page === 'orders') {
        $orders = $pdo->query("SELECT o.*, p.full_name, u.full_name doctor_name FROM orders o JOIN patients p ON p.id=o.patient_id JOIN users u ON u.id=o.doctor_id ORDER BY o.created_at DESC")->fetchAll();
        ?><div class="page-head"><div><span class="eyebrow">ORDER MANAGEMENT</span><h1>Semua Order</h1><p class="muted">Daftar order medis dan status terakhirnya.</p></div><a class="btn primary" href="index.php?page=new_order">+ Buat Order</a></div><section class="panel"><div class="table-wrap"><table><thead><tr><th>Order</th><th>Pasien</th><th>Jenis</th><th>Unit</th><th>Prioritas</th><th>Status</th></tr></thead><tbody><?php foreach($orders as $o): ?><tr><td><?= e($o['order_no']) ?></td><td><?= e($o['full_name']) ?></td><td><?= e($o['order_type']) ?></td><td><?= e($o['target_unit']) ?></td><td><?= e($o['priority']) ?></td><td><span class="badge <?= strtolower(str_replace(' ','-', $o['status'])) ?>"><?= e($o['status']) ?></span></td></tr><?php endforeach; if (!$orders): ?><tr><td colspan="6" class="empty">Belum ada order.</td></tr><?php endif; ?></tbody></table></div></section><?php
    } elseif ($page === 'new_order') {
        $patients = $pdo->query('SELECT id, medical_record_no, full_name FROM patients ORDER BY full_name')->fetchAll();
        ?><div class="page-head"><div><span class="eyebrow">PEMBUATAN ORDER</span><h1>Buat Order Baru</h1><p class="muted">Isi data order lalu simpan untuk diproses.</p></div></div><section class="panel form-panel"><form method="post" class="form-grid"><label>Pasien<select name="patient_id" required><option value="">Pilih pasien</option><?php foreach($patients as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['medical_record_no'].' • '.$p['full_name']) ?></option><?php endforeach; ?></select></label><label>Jenis Order<select name="order_type"><option>Laboratorium</option><option>Radiologi</option><option>Farmasi</option><option>Tindakan Medis</option><option>Konsultasi</option><option>Diet</option></select></label><label>Prioritas<select name="priority"><option>Rutin</option><option>Urgent</option><option>STAT</option></select></label><label>Unit Tujuan<select name="target_unit"><option>Laboratorium</option><option>Radiologi</option><option>Farmasi</option><option>Rawat Inap</option><option>Gizi</option></select></label><label class="full">Detail Order<textarea name="detail" rows="5" required placeholder="Tulis detail pemeriksaan / obat / tindakan..."></textarea></label><div class="full actions"><a class="btn secondary" href="index.php?page=dashboard">Batal</a><button class="btn primary" type="submit">Simpan Order</button></div></form></section><?php
    } elseif ($page === 'workqueue') {
        $orders = $pdo->query("SELECT o.id,o.order_no,p.full_name,o.order_type,o.target_unit,o.priority,o.status,o.detail FROM orders o JOIN patients p ON p.id=o.patient_id ORDER BY o.updated_at DESC")->fetchAll();
        ?><div class="page-head"><div><span class="eyebrow">WORK QUEUE</span><h1>Antrean Unit</h1><p class="muted">Perbarui status order yang sedang ditangani unit.</p></div></div><div class="queue-grid"><?php foreach($orders as $o): ?><div class="queue-card"><div class="queue-top"><span class="badge <?= strtolower(str_replace(' ','-', $o['status'])) ?>"><?= e($o['status']) ?></span><span class="small">#<?= e($o['order_no']) ?></span></div><h3><?= e($o['full_name']) ?></h3><p class="muted"><?= e($o['order_type']) ?> • <?= e($o['target_unit']) ?></p><p><?= e($o['detail']) ?></p><form method="post" action="index.php?page=update_order" class="queue-form"><input type="hidden" name="id" value="<?= $o['id'] ?>"><select name="status"><option <?= $o['status']==='Diproses'?'selected':'' ?>>Diproses</option><option <?= $o['status']==='Dikirim'?'selected':'' ?>>Dikirim</option><option <?= $o['status']==='Selesai'?'selected':'' ?>>Selesai</option><option <?= $o['status']==='Dibatalkan'?'selected':'' ?>>Dibatalkan</option></select><input name="result_text" placeholder="Catatan hasil (opsional)"><button class="btn primary small-btn" type="submit">Simpan</button></form></div><?php endforeach; if (!$orders): ?><div class="empty-panel">Belum ada order di antrean.</div><?php endif; ?></div><?php
    } elseif ($page === 'audit') {
        $logs = $pdo->query("SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 50")->fetchAll();
        ?><div class="page-head"><div><span class="eyebrow">AUDIT TRAIL</span><h1>Riwayat Aktivitas</h1><p class="muted">Catatan aktivitas pengguna dalam sistem.</p></div></div><section class="panel"><div class="table-wrap"><table><thead><tr><th>Waktu</th><th>Pengguna</th><th>Aksi</th><th>Deskripsi</th></tr></thead><tbody><?php foreach($logs as $l): ?><tr><td><?= e($l['created_at']) ?></td><td><?= e($l['full_name'] ?? '-') ?></td><td><?= e($l['action']) ?></td><td><?= e($l['description']) ?></td></tr><?php endforeach; ?></tbody></table></div></section><?php
    } else {
        ?><div class="panel"><h2>Halaman tidak ditemukan</h2><p class="muted">Silakan pilih menu di sidebar.</p></div><?php
    }
    return ob_get_clean();
}

$content = page_content($page, $pdo, $user);
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(ucwords(str_replace('_',' ', $page))) ?> • CPOE SIMRS</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">
    <div class="brand"><span class="brand-mark">C</span><div><strong>CPOE</strong><small>SIMRS • Order Mgmt</small></div></div>
    <div class="section-title">Workspace</div>
    <nav>
      <a class="<?= $page==='dashboard'?'active':'' ?>" href="index.php?page=dashboard">Dashboard</a>
      <a class="<?= $page==='orders'?'active':'' ?>" href="index.php?page=orders">Order Management</a>
      <a class="<?= $page==='new_order'?'active':'' ?>" href="index.php?page=new_order">Buat Order</a>
      <a class="<?= $page==='workqueue'?'active':'' ?>" href="index.php?page=workqueue">Work Queue</a>
      <a class="<?= $page==='patients'?'active':'' ?>" href="index.php?page=patients">Pasien</a>
      <a class="<?= $page==='audit'?'active':'' ?>" href="index.php?page=audit">Audit Trail</a>
    </nav>
    <div class="sidebar-bottom"><div class="session-label">Session</div><div class="user-chip"><strong><?= e($user['full_name']) ?></strong><span><?= e($user['role']) ?></span></div><a class="logout" href="index.php?page=logout">Keluar</a></div>
  </aside>
  <main class="main">
    <header class="topbar"><div><strong><?= e($user['unit_name']) ?></strong><span> / CPOE SIMRS</span></div><div class="role-pill"><?= e($user['role']) ?></div></header>
    <div class="content"><?= $content ?></div>
  </main>
</div>
</body>
</html>
