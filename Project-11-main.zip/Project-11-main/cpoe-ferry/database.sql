CREATE DATABASE IF NOT EXISTS cpoe_teman CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cpoe_teman;

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('Dokter','Perawat','Laboratorium','Radiologi','Farmasi','Gizi','Administrator') NOT NULL,
    unit_name VARCHAR(100) NOT NULL DEFAULT 'Rawat Inap',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS patients (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    medical_record_no VARCHAR(30) NOT NULL UNIQUE,
    full_name VARCHAR(120) NOT NULL,
    gender ENUM('L','P') NOT NULL,
    birth_date DATE NOT NULL,
    room VARCHAR(50) DEFAULT NULL,
    allergy TEXT DEFAULT NULL,
    diagnosis VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_no VARCHAR(30) NOT NULL UNIQUE,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    order_type ENUM('Laboratorium','Radiologi','Farmasi','Tindakan Medis','Konsultasi','Diet') NOT NULL,
    priority ENUM('Rutin','Urgent','STAT') NOT NULL DEFAULT 'Rutin',
    detail TEXT NOT NULL,
    target_unit VARCHAR(100) NOT NULL,
    status ENUM('Menunggu Validasi','Dikirim','Diproses','Selesai','Dibatalkan') NOT NULL DEFAULT 'Menunggu Validasi',
    result_text TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_orders_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
    CONSTRAINT fk_orders_doctor FOREIGN KEY (doctor_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    action VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO users (username, password, full_name, role, unit_name) VALUES
('dokter', '$2y$12$Tt3L6W.Q5ywX3GTqbiw6.uP08lCfqz0eT3nTIK0KU4RIUAgzqeJHC', 'dr. Raka Pratama', 'Dokter', 'Rawat Inap'),
('perawat', '$2y$12$tdW4M/0KBwKKujVtJFjn3.g9b6mJNB9aM7vqbWrGEreRDzDDY5v0a', 'Ns. Sinta Lestari', 'Perawat', 'Rawat Inap'),
('lab', '$2y$12$9v1VRqS.2LCjCqwDsOaIFOsKc1AfppOhFYwY5WS8L3VFiP1cItT62', 'Budi Santoso', 'Laboratorium', 'Laboratorium'),
('farmasi', '$2y$12$M..VMqVob.mNmHLm8EVxVuH4Asj6LPOmyjVxaRyOmrWVzK2ih6c9q', 'Ayu Ramadhani', 'Farmasi', 'Farmasi'),
('radiologi', '$2y$12$4hA8hQoJu57zQdcA/oyLXOGDXSPfyyAHs6mMCY2QWSQN6hyzYXute', 'Dimas Wijaya', 'Radiologi', 'Radiologi'),
('gizi', '$2y$12$CTClFiEPnKtUnDoiOx0OPeGEuEOgD90hk21YYIMOOxkYC0y2YWdIC', 'Nadia Putri', 'Gizi', 'Gizi'),
('admin', '$2y$12$nwqzNPI.fcV6sQsXd.pDruqdyqmoIK2MPcWwGYmxKLivnqvq6ovcm', 'Admin SIMRS', 'Administrator', 'SIMRS')
ON DUPLICATE KEY UPDATE username=username;

INSERT INTO patients (medical_record_no, full_name, gender, birth_date, room, allergy, diagnosis) VALUES
('RM-2026-001', 'Andi Saputra', 'L', '1987-04-13', '3A-12', 'Tidak ada', 'Gastritis'),
('RM-2026-002', 'Siti Rahma', 'P', '1992-11-02', '2B-08', 'Penisilin', 'Demam tifoid'),
('RM-2026-003', 'Bima Nugraha', 'L', '1979-08-22', '1C-03', 'Tidak ada', 'Hipertensi');
